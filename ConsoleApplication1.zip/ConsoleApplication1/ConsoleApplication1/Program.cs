﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

           
            int[] table = new int[10];

            Console.Write("Enter your number");

            int b;
            b = Int32.Parse(Console.ReadLine());
            for (int i = 1; i < table.Length; i++ )
            {
                table[i] = b * i;

                Console.WriteLine(b+" * " + i + " = " + table[i]);

            }


            Console.ReadLine();
        }

    }
}
