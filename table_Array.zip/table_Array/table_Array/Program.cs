﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace table_Array
{
    class Program
    {
        static void Main(string[] args)
        {

            

            Console.Write("Enter your number");

            int Table_No;
            Table_No = Int32.Parse(Console.ReadLine());

            int[] Table_Answer = new int[10];
            for (int Multiply = 1; Multiply <= Table_Answer.Length; Multiply++)
            {
                Table_Answer[Multiply] = Table_No * Multiply;
                Console.WriteLine(Table_No + " * " + Multiply + " = " + Table_Answer[Multiply]);
            }

            Console.ReadLine();

        }
    }
}
