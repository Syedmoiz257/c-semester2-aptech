﻿using System;

namespace Markshet
{
    class Program
    {
        double markeng , markmat,markche,markphy,markcomp,total , per;
        private double totalmarks = Convert.ToDouble(500);

        public void Show() {

            Console.WriteLine("    Student Marks Sheet");
            Console.WriteLine("");

            Console.WriteLine("Enter English Marks");
            markeng = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Math Marks");
            markmat = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Chemistry Marks");
            markche = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Physics Marks");
            markphy = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Computer Marks");
            markcomp = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
        }
        
        public void Result() {

            total = markeng + markmat + markphy + markcomp + markche;
            Console.WriteLine("Total Obtained Marks " + total + ".");
            
        }

        public void Percentage() {

            per = (total * 100) / totalmarks;
            Console.WriteLine("Your Percentage Is " + per + " %.");
            
        }

        public void Grade() {

            if (per >=80 && per <=100)
            {
                Console.WriteLine("Your Grade Is A+ ");
            }

            else if (per >= 70 && per <= 79)
            {
                Console.WriteLine("Your Grade Is A ");
            }

            else if (per >= 50 && per <= 69)
            {
                Console.WriteLine("Your Grade Is B ");
            }

            else if (per >= 35 && per <= 49)
            {
                Console.WriteLine("Your Grade Is C ");
            }

            else if (per <= 34)
            {
                Console.Write("OoPps Failed");     
            }

            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            Program pro = new Program();
            pro.Show();
            pro.Result();
            pro.Percentage();
            pro.Grade();
        }
    }
}
